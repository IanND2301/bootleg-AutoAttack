## AutoAttack v%version% for Minecraft %mc_versions%
### What's new?

%changelog%

Full Changelog: [`v%last_version%...v%version%`](https://github.com/vin350/AutoAttack/compare/v%last_version%...v%version%)