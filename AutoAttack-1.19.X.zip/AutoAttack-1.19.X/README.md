# AutoAttack LOOK AT THE BRANCHES
<h3 align="center">
<a href="https://modrinth.com/mod/autoattack" target="_blank">Modrinth Homepage</a> | <a href="https://www.curseforge.com/minecraft/mc-mods/autoattack" target="_blank">CurseForge Homepage</a>
</h3>

Auto Attack makes it so that holding the attack button autoswings the sword, similar to the combat snapshots.
